const db = require('../utils/db');

const User = {
  create: async (user) => {
    try {
      const result = await db('users').insert(user).returning('*');
      return result;
    } catch (error) {
      throw new Error(`Error creating user: ${error.message}`);
    }
  },

  findByEmail: async (email) => {
    try {
      const user = await db('users').where({ email }).first();
      return user;
    } catch (error) {
      throw new Error(`Error finding user by email: ${error.message}`);
    }
  },

  findById: async (id) => {
    try {
      const user = await db('users').where({ id }).first();
      return user;
    } catch (error) {
      throw new Error(`Error finding user by id: ${error.message}`);
    }
  },

  updateStatus: async (email, status) => {
    try {
      const result = await db('users').where({ email }).update({ status }).returning('*');
      return result;
    } catch (error) {
      throw new Error(`Error updating user status: ${error.message}`);
    }
  },

  deleteById: async (id) => {
    try {
      const result = await db('users').where({ id }).del();
      return result;
    } catch (error) {
      throw new Error(`Error deleting user by id: ${error.message}`);
    }
  },

  findAll: async () => {
    try {
      const users = await db('users').select('*');
      return users;
    } catch (error) {
      throw new Error(`Error fetching all users: ${error.message}`);
    }
  },
};

module.exports = User;
