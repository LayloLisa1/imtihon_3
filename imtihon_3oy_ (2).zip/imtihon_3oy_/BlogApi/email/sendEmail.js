const nodemailer = require('nodemailer');
const path = require('path');

const transporter = nodemailer.createTransport({ 
    host: "smtp.gmail.com", 
    port: 465, 
    secure: true, 
    auth: { 
        user:'laylobobohonova2008@gmail.com',
        pass: 'vasm pklg urdd evbg' 
    } 
}) 
 
async function main(otp, email) { 
 
    const info = await transporter.sendMail({ 
        to:"munisamusayevaa@gmail.com", 
        subject: "3 daqiqalik kodingiz", 
        text: "Hello world", 
        html: ` 
            <h1>  Assalomu alaykum sizning 1 daqiqalik kodingiz: ${otp}  </h1> 
        ` 
    }) 
 
    console.log("Message sent: %s", info.messageId); 
}