const db = require('../utils/db');

const User = {
  create: (user) => db('users').insert(user).returning('*'),
  findByEmail: (email) => db('users').where({ email }).first(),
  findById: (id) => db('users').where({ id }).first(),
  update: (id, updates) => db('users').where({ id }).update(updates).returning('*'),
  deleteById: (id) => db('users').where({ id }).del(),
  findAll: () => db('users').select('*'),
  findByUsername: (username) => db('users').where({ username }).first(),
  deleteByEmail: (email) => db('users').where({ email }).del(),
  count: () => db('users').count().first(),
  findByStatus: (status) => db('users').where({ status }).select('*'),
};

module.exports = User;
