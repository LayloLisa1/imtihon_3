const express = require('express');
const { logger, requestLogger } = require('./utils/logger');
const app = express();
app.use(requestLogger);

app.get('/', (req, res) => {
  logger.info('Hello, logging!');
  res.send('Hello World!');
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  logger.info(`Server is running on port ${PORT}`);
});
